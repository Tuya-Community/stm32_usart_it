中断方式：从PC上发送固定数量字符到开发板，开发板收到后原样发回PC，通过串口助手观测发送
把串口1接收到的2个字符发送出去 


Interrupt mode:  Send a fixed number of characters from the PC to the development board, 
the development board received the original sent back to the PC, 
through the serial port assistant observation and send.

Send the two characters received in serial port 1  